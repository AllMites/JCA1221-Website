import { MapPin, ArrowRight, ArrowUpRight } from 'lucide-react'
import { useRef } from 'react'
import type { ProjectCard as ProjectCardType } from '../types'

interface ProjectCarouselProps {
  projects: ProjectCardType[]
  onProjectClick?: (projectId: string) => void
}

const STATUS_COLORS: Record<string, string> = {
  operational: 'bg-emerald-500',
  development: 'bg-amber-500',
  planning: 'bg-blue-400',
}

const STATUS_LABELS: Record<string, string> = {
  operational: 'Operational',
  development: 'In Development',
  planning: 'Planning',
}

function ProjectCardItem({ project, onClick }: { project: ProjectCardType; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group/card flex-shrink-0 w-[380px] sm:w-[420px] text-left rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden hover:border-blue-400/50 dark:hover:border-blue-500/50 hover:-translate-y-1 hover:shadow-2xl hover:shadow-blue-500/10 dark:hover:shadow-blue-500/5 transition-all duration-500 cursor-pointer"
    >
      {/* Image area */}
      <div className="relative h-52 bg-gradient-to-br from-blue-100 to-slate-200 dark:from-blue-950 dark:to-slate-800 overflow-hidden">
        {/* Gradient fallback image */}
        <div className="absolute inset-0 opacity-30 dark:opacity-50 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-400 via-blue-600 to-blue-900 group-hover/card:opacity-50 dark:group-hover/card:opacity-70 transition-opacity duration-500" />
        <div className="absolute inset-0 bg-gradient-to-t from-white/90 via-white/40 to-transparent dark:from-slate-900/90 dark:via-slate-900/40" />

        {/* Status badge */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm text-slate-700 dark:text-slate-300 shadow-sm">
          <span className={`w-2 h-2 rounded-full ${STATUS_COLORS[project.status] ?? 'bg-slate-400'}`} />
          {STATUS_LABELS[project.status] ?? project.status}
        </div>

        {/* Hover overlay — award + stats */}
        <div className="absolute inset-0 bg-blue-950/80 opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 flex flex-col justify-center px-6 py-4 text-white">
          {project.award && (
            <div className="mb-4">
              <p className="text-xs uppercase tracking-wider text-amber-400 font-medium mb-1">Award</p>
              <p className="text-sm font-semibold leading-snug">{project.award.title}</p>
              <p className="text-xs text-blue-300 mt-0.5">{project.award.organization}, {project.award.year}</p>
            </div>
          )}
          {project.stats.length > 0 && (
            <div className="flex gap-6">
              {project.stats.map((stat) => (
                <div key={stat.label}>
                  <p className="text-lg font-bold font-heading">{stat.value}</p>
                  <p className="text-xs text-blue-300">{stat.label}</p>
                </div>
              ))}
            </div>
          )}
          <div className="mt-4 flex items-center gap-1 text-xs text-blue-300 opacity-0 group-hover/card:opacity-100 transition-opacity delay-200">
            View project details <ArrowUpRight size={12} />
          </div>
        </div>
      </div>

      {/* Content — always visible */}
      <div className="p-5">
        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-2">
          <MapPin size={12} />
          <span className="truncate">{project.location}</span>
        </div>

        <h3 className="font-bold font-heading text-slate-900 dark:text-white text-lg leading-tight group-hover/card:text-blue-600 dark:group-hover/card:text-blue-400 transition-colors duration-300">
          {project.name}
        </h3>
      </div>
    </button>
  )
}

export function ProjectCarousel({ projects, onProjectClick }: ProjectCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const handleMouseEnter = () => {
    // Pause auto-scroll intention — handled by CSS
  }

  return (
    <section className="relative py-20 overflow-hidden bg-slate-900 dark:bg-black">
      {/* Section background texture */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/50 to-slate-900" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent" />

      {/* Section header */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <p className="text-sm font-medium font-heading uppercase tracking-[0.2em] text-blue-400 mb-3">
          Track Record
        </p>
        <h2 className="text-3xl sm:text-4xl font-bold font-heading text-white mb-4">
          Projects That Restore Ecosystems
        </h2>
        <p className="text-blue-200/70 max-w-xl text-base leading-relaxed">
          Each facility is a public-private partnership built on integrity, delivering measurable
          environmental outcomes for Philippine communities.
        </p>
      </div>

      {/* Horizontal scroll container */}
      <div className="relative z-10">
        <div
          ref={scrollRef}
          onMouseEnter={handleMouseEnter}
          className="flex gap-5 px-4 sm:px-6 lg:px-8 pb-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory"
          style={{ scrollPaddingInline: 'calc((100vw - 1280px) / 2 + 2rem)', paddingLeft: 'max(1rem, calc((100vw - 1280px) / 2 + 2rem))', paddingRight: 'max(1rem, calc((100vw - 1280px) / 2 + 2rem))' }}
        >
          {projects.map((project) => (
            <div key={project.id} className="snap-start">
              <ProjectCardItem
                project={project}
                onClick={() => onProjectClick?.(project.id)}
              />
            </div>
          ))}

          {/* End hint card */}
          <div className="flex-shrink-0 w-[280px] flex items-center justify-center rounded-2xl border border-dashed border-slate-700 dark:border-slate-800 bg-slate-800/30">
            <div className="text-center p-6">
              <ArrowRight size={24} className="text-slate-600 mx-auto mb-2" />
              <p className="text-sm text-slate-500 font-heading">
                More projects coming online
              </p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </section>
  )
}
